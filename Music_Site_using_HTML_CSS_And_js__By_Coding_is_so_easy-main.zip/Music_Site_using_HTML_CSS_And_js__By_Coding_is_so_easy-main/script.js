const wrapper = document.querySelector(".wrapper"),
    musicImg = wrapper.querySelector(".img-area img"),
    musicName = wrapper.querySelector(".song-details .name"),
    musicArtist = wrapper.querySelector(".song-details .artist"),
    playPauseBtn = wrapper.querySelector(".play-pause"),
    prevBtn = wrapper.querySelector("#prev"),
    nextBtn = wrapper.querySelector("#next"),
    mainAudio = wrapper.querySelector("#main-audio"),
    progressBar = wrapper.querySelector(".progress-bar"),
    progressArea = wrapper.querySelector(".progress-area"),
    musicList = wrapper.querySelector(".music-list"),
    moreMusicBtn = wrapper.querySelector("#more-music"),
    closemoreMusic = wrapper.querySelector("#close")


//show Music List onclick Music Icon

//Load Funcion

//Music List 

//Playing Song

//play and Pause Event

//play music Function

//Pause Music Function

//Update Progress Bar as to music Curr Time

//update Music curr time as to Progress Bar

//next event

//next Function

//Prev Event

// Prev Function

//change loop shuffle and repeat icon

//After End Song
