let allMusic = [
    {
        name: "Kina - get you the moon (slowed)",
        artist: "Kina",
        img: "music-1",
        src: "music-1"
    },
    {
        name: "losing interest ",
        artist: "Shiloh Dynasty",
        img: "music-2",
        src: "music-2"
    },
    {
        name: "tell me why i'm waiting ",
        artist: "timmis & shiloh",
        img: "music-3",
        src: "music-3"
    }
]